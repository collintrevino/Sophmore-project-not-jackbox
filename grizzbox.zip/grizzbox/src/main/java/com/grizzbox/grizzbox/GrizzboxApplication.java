package com.grizzbox.grizzbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.grizzbox.grizzbox.AccessCode.codegenerator;

@SpringBootApplication
@RestController
public class GrizzboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrizzboxApplication.class, args);

	}
@GetMapping("/")
		public String greet() {
			return "welcome to grizzbox";
		}
	}


