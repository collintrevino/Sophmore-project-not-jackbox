package com.grizzbox.grizzbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrizzboxApplicationTests {

	@Test
	void contextLoads() {
	}

}
